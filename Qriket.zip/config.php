<?php

$email = "kadal15@gmail.com";
$password = "Darking1";

//Pillih Warna 0 untuk hijau 1 untuk kuning
$collor = "0";

// Pilih Jumlah Spin Saran 1 - 5
$amount = "1";



